'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { AppProvider, useAppContext } from './context/AppContext';
import './globals.css';

function LayoutContent({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const router = useRouter();
    const { points, cartItems, globalSearchInput, setGlobalSearchInput, bestSellingItems, currentView, setCurrentView } = useAppContext();
    const [showProfileModal, setShowProfileModal] = useState(false);
    const [showGlobalSearch, setShowGlobalSearch] = useState(false);

    useEffect(() => {
        if (!document.getElementById('leaflet-js-cdn')) {
            const scriptLeaflet = document.createElement('script');
            scriptLeaflet.id = 'leaflet-js-cdn';
            scriptLeaflet.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
            scriptLeaflet.async = true;
            document.head.appendChild(scriptLeaflet);
        }
    }, []);

    const simulateProductClick = (name: string, price: number, img: string) => {
        alert(`Mensimulasikan klik produk: ${name}.`);
        setShowGlobalSearch(false);
        setGlobalSearchInput('');
    };

    const handleNavClick = (view: string) => {
        setCurrentView(view);
        if (pathname !== '/') {
            router.push('/');
        }
    };

    return (
        <div className="app-container">
            <header className="main-header" style={{ background: '#14403a', color: 'white', padding: '15px 30px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'sticky', top: 0, zIndex: 100, borderBottom: '4px solid #fff24b' }}>
                <div className="logo-area" style={{ display: 'flex', alignItems: 'center', fontWeight: 'bold', fontSize: '1.2rem' }}>
                    <img 
                        src="/Assets/Logodandelionbake.png" 
                        alt="Logo Header" 
                        style={{ width: '40px', height: '40px', marginRight: '10px', borderRadius: '50%', objectFit: 'cover' }} 
                    />
                    Dandelion Bake
                </div>
                <nav>
                    <ul className="nav-links" style={{ display: 'flex', gap: '20px', alignItems: 'center', listStyle: 'none', margin: 0, padding: 0, fontSize: '0.9rem' }}>
                        <li><a onClick={() => handleNavClick('home-view')} style={{ cursor: 'pointer', fontWeight: currentView === 'home-view' ? 'bold' : 'normal', color: currentView === 'home-view' ? '#fff24b' : 'white' }}>Our Menu</a></li>
                        <li><a onClick={() => handleNavClick('rewards-view')} style={{ cursor: 'pointer', fontWeight: currentView === 'rewards-view' ? 'bold' : 'normal', color: currentView === 'rewards-view' ? '#fff24b' : 'white' }}>Rewards</a></li>
                        <li><a onClick={() => handleNavClick('news-view')} style={{ cursor: 'pointer', fontWeight: currentView === 'news-view' ? 'bold' : 'normal', color: currentView === 'news-view' ? '#fff24b' : 'white' }}>News & Promo</a></li>
                        <li><a onClick={() => handleNavClick('group-order-view')} style={{ cursor: 'pointer', fontWeight: currentView === 'group-order-view' ? 'bold' : 'normal', color: currentView === 'group-order-view' ? '#fff24b' : 'white' }}>Group Order</a></li>
                        <li><a onClick={() => handleNavClick('store-view')} style={{ cursor: 'pointer', fontWeight: currentView === 'store-view' ? 'bold' : 'normal', color: currentView === 'store-view' ? '#fff24b' : 'white' }}>Store Radar</a></li>
                        <li style={{ borderLeft: '2px solid rgba(255,255,255,0.3)', height: '20px', margin: '0 5px' }}></li>
                        <li>
                            <Link href="/checkout" style={{ color: pathname === '/checkout' ? '#fff24b' : 'white', textDecoration: 'none', fontWeight: pathname === '/checkout' ? 'bold' : 'normal' }}>
                                Keranjang ({cartItems?.length || 0})
                            </Link>
                        </li>
                        <li>
                            <Link href="/pesanan" style={{ color: pathname === '/pesanan' ? '#fff24b' : 'white', textDecoration: 'none', fontWeight: pathname === '/pesanan' ? 'bold' : 'normal' }}>
                                Orderan
                            </Link>
                        </li>
                    </ul>
                </nav>
            </header>

            <main style={{ minHeight: 'calc(100vh - 150px)' }}>
                {children}
            </main>

            <footer style={{ background: '#111', color: 'white', padding: '40px 0', marginTop: '60px' }}>
                <div className="container" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '40px' }}>
                    <div className="footer-col">
                        <h3 style={{ color: '#fff24b', marginBottom: '20px' }}>Dandelion Bake</h3>
                        <p style={{ fontSize: '0.85rem', lineHeight: '1.6', opacity: 0.8 }}>Roti artisan premium dengan bahan pilihan. Dipanggang fresh setiap hari untuk kebahagiaan Anda.</p>
                    </div>
                    <div className="footer-col">
                        <h3 style={{ marginBottom: '20px' }}>Menu Cepat</h3>
                        <ul style={{ listStyle: 'none', padding: 0, fontSize: '0.85rem' }}>
                            <li onClick={() => handleNavClick('home-view')} style={{ marginBottom: '10px', cursor: 'pointer' }}>Katalog Roti</li>
                            <li onClick={() => handleNavClick('store-view')} style={{ marginBottom: '10px', cursor: 'pointer' }}>Lokasi Toko</li>
                            <li onClick={() => handleNavClick('news-view')} style={{ marginBottom: '10px', cursor: 'pointer' }}>Promo Hari Ini</li>
                        </ul>
                    </div>
                    <div className="footer-col">
                        <h3 style={{ marginBottom: '20px' }}>Layanan</h3>
                        <ul style={{ listStyle: 'none', padding: 0, fontSize: '0.85rem' }}>
                            <li style={{ marginBottom: '10px' }}>Syarat & Ketentuan</li>
                            <li style={{ marginBottom: '10px' }}>Kebijakan Privasi</li>
                            <li style={{ marginBottom: '10px' }}>Hubungi Kami</li>
                        </ul>
                    </div>
                    <div className="footer-col">
                        <h3 style={{ marginBottom: '20px' }}>Ikuti Kami</h3>
                        <div style={{ display: 'flex', gap: '15px', fontSize: '1.5rem' }}>
                            <i className="fab fa-instagram"></i>
                            <i className="fab fa-facebook"></i>
                            <i className="fab fa-twitter"></i>
                            <i className="fab fa-tiktok"></i>
                        </div>
                    </div>
                </div>
                <div style={{ textAlign: 'center', marginTop: '40px', paddingTop: '20px', borderTop: '1px solid #333', fontSize: '0.8rem', opacity: 0.6 }}>
                    &copy; 2026 Dandelion Bake. All rights reserved.
                </div>
            </footer>
        </div>
    );
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
    return (
        <html lang="id">
            <head>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
                <title>Dandelion Bake - Roti Enak Setiap Hari</title>
            </head>
            <body>
                <AppProvider>
                    <LayoutContent>
                        {children}
                    </LayoutContent>
                </AppProvider>
            </body>
        </html>
    );
}
